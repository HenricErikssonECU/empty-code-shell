/***************************************   HOME   ***************************************/

function toggle(){
   var toggle = document.getElementById("services-section");
    if (toggle.style.display==="none") {
        toggle.style.display = "block"
    } else {
        toggle.style.display = "none"
    }
}

 














































































